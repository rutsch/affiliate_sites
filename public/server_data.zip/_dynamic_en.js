//code for en
var strHtmlLightbox='<div class="lb_template"><div class="lb_wrapper"><table cellpadding="0" cellspacing="0"><tr><td><div class="lb_title"></div><div class="lb_close" onclick="lightbox.close()"></div></td></tr><tr><td class="lb_tools_wrapper"><div class="lb_tools"><div class="toolbar_item toggle_download_add"><div class="toolbar_item_icon"></div><div class="toolbar_item_link">Add page to your PDF</div><div class="all_downloads_count">(0)</div></div><div class="toolbar_item toggle_download_delete"><div class="toolbar_item_icon"></div><div class="toolbar_item_link">Delete page from PDF</div><div class="all_downloads_count">(0)</div></div><div class="toolbar_item print_page"><div class="toolbar_item_icon"></div><div class="toolbar_item_link" onclick="printPageNote()">Print this page</div></div><div class="toolbar_item download_graph"><div class="toolbar_item_icon"></div><div class="toolbar_item_link">Download graph</div></div></div></td></tr><tr><td><div class="lb_content"></div></td></tr><tr><td><div class="lb_footer"><table><tr><td width="50%" class="prev"><div class="lb_previous" style="display: none;"></div></td><td width="50%" class="next"><div class="lb_next" style="display: none;"></div></td></tr></table></div></td></tr></table></div></div>';
var strErrorDisclaimer='<p id="error_disclaimer">				If this error persists, please contact the <a href="mailto:rutger.scheepens@philips.com">Site administrator</a></p>';
var strHtmlGlossaryTemplate='<div class="glossary_content"><div class="glossary_lb_top"><div class="lb_close"></div><p class="title">[glossary_title]</p></div><div class="glossary_lb_middle"><p>[glossary_content]</p><a href="/annual_report_2012/en/definitions_and_abbreviations.aspx">Complete glossary</a></div><div class="glossary_lb_bottom"></div></div>';
var bolDebugging=true;
var urlHomePage='/index.aspx';
var crscRootPath='';
var tinyUrl = 'http://json-tinyurl.appspot.com';
var googleShortUrl = 'http://www.googleapis.com/urlshortener/v1/url';
// Set Twitter variables
var bolUseTwitter = true;
var twitterAccount = 'PhilipsPR';
var twitterMessage = "";
var twitterShareUrl = 'http://twitter.com/share';
var twitterSearchUrl = 'http://feeds.tidytweet.com/client/phannualreport/feed/philipspr/legacy.atom';
// Set Facebook variables
var bolUseFacebook = true;
var facebookAccount = 'philips';
var facebookShareUrl = 'http://www.facebook.com/sharer.php';
// Set YouTube variables
var bolUseYoutube = true;
var youtubeAccount = 'Philips';
var youtubeSearchUrl = 'http://gdata.youtube.com/feeds/api/users/Philips/uploads?v=2&orderby=relevance_lang_en&alt=json-in-script&max-results=[max_results]&callback=?&lang=en';
// Set Philips News Feed variables
var bolUsePhilipsNewsFeed = true;
var newsFeedAccount = 'Philips News Feed';
var newsFeedSearchUrl = 'http://www.newscenter.philips.com/rss/NewsCenter/NewsCenterHomeRSSFeed.aspx?type=NewsCenterPressRelease&locale=global&bus=Corporate';

var objArrNotes = 
		{ notes: [ 
			
			{
				note_id: "1",
				node_id: "10978212",
				note_name: "Income from operations",
				page_id: "1152520",
				page_url: "/annual_report_2012/en/group_financial_statements/notes/income_from_operations.aspx"
			}
			,
			{
				note_id: "2",
				node_id: "10978229",
				note_name: "Financial income and expenses",
				page_id: "1152611",
				page_url: "/annual_report_2012/en/group_financial_statements/notes/financial_income_and_expenses.aspx"
			}
			,
			{
				note_id: "3",
				node_id: "10978244",
				note_name: "Income taxes",
				page_id: "1152702",
				page_url: "/annual_report_2012/en/group_financial_statements/notes/income_taxes.aspx"
			}
			,
			{
				note_id: "4",
				node_id: "10978271",
				note_name: "Investments in associates",
				page_id: "1152793",
				page_url: "/annual_report_2012/en/group_financial_statements/notes/investments_in_associates.aspx"
			}
			,
			{
				note_id: "5",
				node_id: "10977950",
				note_name: "Discontinued operations and other assets classified as held for sale",
				page_id: "1152338",
				page_url: "/annual_report_2012/en/group_financial_statements/notes/discontinued_operations.aspx"
			}
			,
			{
				note_id: "6",
				node_id: "10977957",
				note_name: "Earnings per share",
				page_id: "20399594",
				page_url: "/annual_report_2012/en/group_financial_statements/notes/earnings_per_share.aspx"
			}
			,
			{
				note_id: "7",
				node_id: "10977962",
				note_name: "Acquisitions and divestments",
				page_id: "2",
				page_url: "/annual_report_2012/en/group_financial_statements/notes/acquisitions_and_divestments.aspx"
			}
			,
			{
				note_id: "8",
				node_id: "10977975",
				note_name: "Property, plant and equipment",
				page_id: "1163531",
				page_url: "/annual_report_2012/en/group_financial_statements/notes/property_plant_and_equipment.aspx"
			}
			,
			{
				note_id: "9",
				node_id: "10977992",
				note_name: "Goodwill",
				page_id: "1163713",
				page_url: "/annual_report_2012/en/group_financial_statements/notes/goodwill.aspx"
			}
			,
			{
				note_id: "10",
				node_id: "10978012",
				note_name: "Intangible assets excluding goodwill",
				page_id: "1163622",
				page_url: "/annual_report_2012/en/group_financial_statements/notes/intangible_assets_excluding_goodwill.aspx"
			}
			,
			{
				note_id: "11",
				node_id: "10978026",
				note_name: "Non-current receivables",
				page_id: "1160164",
				page_url: "/annual_report_2012/en/group_financial_statements/notes/non-current_receivables.aspx"
			}
			,
			{
				note_id: "12",
				node_id: "10978029",
				note_name: "Other non-current financial assets",
				page_id: "2001321",
				page_url: "/annual_report_2012/en/group_financial_statements/notes/other_non-current_financial_assets.aspx"
			}
			,
			{
				note_id: "13",
				node_id: "10978034",
				note_name: "Other non-current assets",
				page_id: "1163440",
				page_url: "/annual_report_2012/en/group_financial_statements/notes/other_non-current_assets.aspx"
			}
			,
			{
				note_id: "14",
				node_id: "10978037",
				note_name: "Inventories",
				page_id: "1159891",
				page_url: "/annual_report_2012/en/group_financial_statements/notes/inventories.aspx"
			}
			,
			{
				note_id: "15",
				node_id: "10978041",
				note_name: "Current financial assets",
				page_id: "2045404",
				page_url: "/annual_report_2012/en/group_financial_statements/notes/current_financial_assets.aspx"
			}
			,
			{
				note_id: "16",
				node_id: "10978043",
				note_name: "Other current assets",
				page_id: "1163349",
				page_url: "/annual_report_2012/en/group_financial_statements/notes/other_current_assets.aspx"
			}
			,
			{
				note_id: "17",
				node_id: "10978048",
				note_name: "Current receivables",
				page_id: "1159800",
				page_url: "/annual_report_2012/en/group_financial_statements/notes/current_receivables.aspx"
			}
			,
			{
				note_id: "18",
				node_id: "10978062",
				note_name: "Equity",
				page_id: "1161802",
				page_url: "/annual_report_2012/en/group_financial_statements/notes/equity.aspx"
			}
			,
			{
				note_id: "19",
				node_id: "10978078",
				note_name: "Long-term debt and short-term debt",
				page_id: "1164168",
				page_url: "/annual_report_2012/en/group_financial_statements/notes/long-term_debt_and_short-term_debt.aspx"
			}
			,
			{
				note_id: "20",
				node_id: "10978097",
				note_name: "Provisions",
				page_id: "1163895",
				page_url: "/annual_report_2012/en/group_financial_statements/notes/provisions.aspx"
			}
			,
			{
				note_id: "21",
				node_id: "10978122",
				note_name: "Other non-current liabilities",
				page_id: "1164259",
				page_url: "/annual_report_2012/en/group_financial_statements/notes/other_non-current_liabilities.aspx"
			}
			,
			{
				note_id: "22",
				node_id: "10978127",
				note_name: "Accrued liabilities",
				page_id: "1163804",
				page_url: "/annual_report_2012/en/group_financial_statements/notes/accrued_liabilities.aspx"
			}
			,
			{
				note_id: "23",
				node_id: "10978154",
				note_name: "Other current liabilities",
				page_id: "1160983",
				page_url: "/annual_report_2012/en/group_financial_statements/notes/other_current_liabilities.aspx"
			}
			,
			{
				note_id: "24",
				node_id: "10977831",
				note_name: "Contractual obligations",
				page_id: "1164350",
				page_url: "/annual_report_2012/en/group_financial_statements/notes/contractual_obligations.aspx"
			}
			,
			{
				note_id: "25",
				node_id: "10977840",
				note_name: "Contingent liabilities",
				page_id: "1161711",
				page_url: "/annual_report_2012/en/group_financial_statements/notes/contingent_liabilities.aspx"
			}
			,
			{
				note_id: "26",
				node_id: "10977825",
				note_name: "Cash from (used for) derivatives and securities",
				page_id: "2008709",
				page_url: "/annual_report_2012/en/group_financial_statements/notes/cash_from_derivatives_and_securities.aspx"
			}
			,
			{
				note_id: "27",
				node_id: "10977844",
				note_name: "Proceeds from non-current financial assets",
				page_id: "2008711",
				page_url: "/annual_report_2012/en/group_financial_statements/notes/proceeds_from_non-current_financial_assets.aspx"
			}
			,
			{
				note_id: "28",
				node_id: "10977846",
				note_name: "Assets in lieu of cash from sale of businesses",
				page_id: "1164441",
				page_url: "/annual_report_2012/en/group_financial_statements/notes/assets_in_lieu_of_cash_from_sale_of_businesses.aspx"
			}
			,
			{
				note_id: "29",
				node_id: "10977871",
				note_name: "Pensions and other postretirement benefits",
				page_id: "1163986",
				page_url: "/annual_report_2012/en/group_financial_statements/notes/pensions_and_other_postretirement_benefits.aspx"
			}
			,
			{
				note_id: "30",
				node_id: "10977927",
				note_name: "Share-based compensation",
				page_id: "123465",
				page_url: "/annual_report_2012/en/group_financial_statements/notes/share-based_compensation.aspx"
			}
			,
			{
				note_id: "31",
				node_id: "10978161",
				note_name: "Related-party transactions",
				page_id: "2008713",
				page_url: "/annual_report_2012/en/group_financial_statements/notes/related-party_transactions.aspx"
			}
			,
			{
				note_id: "32",
				node_id: "10978175",
				note_name: "Information on remuneration",
				page_id: "811542",
				page_url: "/annual_report_2012/en/group_financial_statements/notes/information_on_remuneration.aspx"
			}
			,
			{
				note_id: "33",
				node_id: "10978135",
				note_name: "Fair value of financial assets and liabilities",
				page_id: "1164532",
				page_url: "/annual_report_2012/en/group_financial_statements/notes/fair_value_of_financial_assets_and_liabilities.aspx"
			}
			,
			{
				note_id: "34",
				node_id: "10978147",
				note_name: "Details of treasury risks",
				page_id: "2044982",
				page_url: "/annual_report_2012/en/group_financial_statements/notes/details_of_treasury_risks.aspx"
			}
			,
			{
				note_id: "35",
				node_id: "10978194",
				note_name: "Subsequent events",
				page_id: "1164714",
				page_url: "/annual_report_2012/en/group_financial_statements/notes/subsequent_events.aspx"
			}
			,
			{
				note_id: "A",
				node_id: "10978515",
				note_name: "Investments in affiliated companies",
				page_id: "1165715",
				page_url: "/annual_report_2012/en/company_financial_statements/notes/investments_in_affiliated_companies.aspx"
			}
			,
			{
				note_id: "B",
				node_id: "10978520",
				note_name: "Other non-current financial assets",
				page_id: "1160073",
				page_url: "/annual_report_2012/en/company_financial_statements/notes/other_non-current_financial_assets.aspx"
			}
			,
			{
				note_id: "C",
				node_id: "10978525",
				note_name: "Receivables",
				page_id: "1165624",
				page_url: "/annual_report_2012/en/company_financial_statements/notes/receivables.aspx"
			}
			,
			{
				note_id: "D",
				node_id: "10978532",
				note_name: "Shareholders' equity",
				page_id: "1166352",
				page_url: "/annual_report_2012/en/company_financial_statements/notes/shareholders_equity.aspx"
			}
			,
			{
				note_id: "E",
				node_id: "10978542",
				note_name: "Long-term debt and short-term debt",
				page_id: "1166261",
				page_url: "/annual_report_2012/en/company_financial_statements/notes/long-term_debt_and_short-term_debt.aspx"
			}
			,
			{
				note_id: "F",
				node_id: "10978550",
				note_name: "Other current liabilities",
				page_id: "1166079",
				page_url: "/annual_report_2012/en/company_financial_statements/notes/other_current_liabilities.aspx"
			}
			,
			{
				note_id: "G",
				node_id: "10978554",
				note_name: "Net income",
				page_id: "1166443",
				page_url: "/annual_report_2012/en/company_financial_statements/notes/net_income.aspx"
			}
			,
			{
				note_id: "H",
				node_id: "10978557",
				note_name: "Employees",
				page_id: "1166534",
				page_url: "/annual_report_2012/en/company_financial_statements/notes/employees.aspx"
			}
			,
			{
				note_id: "I",
				node_id: "10978560",
				note_name: "Contractual obligations and contingent liabilities not appearing in the balance sheet",
				page_id: "1166625",
				page_url: "/annual_report_2012/en/company_financial_statements/notes/contractual_obligations.aspx"
			}
			,
			{
				note_id: "J",
				node_id: "10978563",
				note_name: "Audit fees",
				page_id: "2040341",
				page_url: "/annual_report_2012/en/company_financial_statements/notes/audit_fees.aspx"
			}
			,
			{
				note_id: "K",
				node_id: "10978565",
				note_name: "Subsequent events",
				page_id: "2039079",
				page_url: "/annual_report_2012/en/company_financial_statements/notes/subsequent_events.aspx"
			}
		
		]}
	;
// Set use AR stats
var bolUseStatsArSystem= true;
var bolUseStatsGoogle= false;
var objAllStatActions = { static: [{selectors: [{type: 'normal',selector: 'div#p-content div.video_player_wrapper div.video-js-box div.video_overlay div.our-big-play-button'}],action: 'hit',event: 'click',values: ['video_player','button_poster-start']},{selectors: [{type: 'normal',selector: 'div#p-body div#p-content div#right_column_toolbar_wrapper div#toolbar_content div.toolbar_item.toggle_download_add'}],action: 'hit',event: 'click',values: ['right_column','button_download-add']},{selectors: [{type: 'normal',selector: 'div#p-body div#p-content div#right_column_toolbar_wrapper div#toolbar_content div.toolbar_item.toggle_download_delete'}],action: 'hit',event: 'click',values: ['right_column','button_download-remove']},{selectors: [{type: 'normal',selector: 'div#p-body div#p-content div#right_column_toolbar_wrapper div#toolbar_content div.toolbar_item.all_downloads'}],action: 'cookie',event: 'click',values: ['right_column','button_download-remove']},{selectors: [{type: 'normal',selector: 'div#p-body div#p-content div#right_column_toolbar_wrapper div#toolbar_content div.toolbar_item.print_page'}],action: 'hit',event: 'click',values: ['right_column','button_print-page']},{selectors: [{type: 'normal',selector: 'div#p-body div#p-content div#right_column_toolbar_wrapper div#toolbar_content div.toolbar_item.mail'},{type: 'normal',selector: '.p-main .share_component div.toolbar_item.mail'}],action: 'hit',event: 'click',values: ['right_column','button_send-friend']},{selectors: [{type: 'normal',selector: 'div#p-body div#p-content div#right_column_toolbar_wrapper div#toolbar_content div.toolbar_item.facebook'},{type: 'normal',selector: '.p-main .share_component div.toolbar_item.facebook'}],action: 'hit',event: 'click',values: ['right_column','button_share-facebook']},{selectors: [{type: 'normal',selector: 'div#p-body div#p-content div#right_column_toolbar_wrapper div#toolbar_content div.toolbar_item.twitter'},{type: 'normal',selector: '.p-main .share_component div.toolbar_item.twitter'}],action: 'hit',event: 'click',values: ['right_column','button_share-twitter']},{selectors: [{type: 'normal',selector: 'div#live_data div.live_data_outer_wrapper div.live_data_inner_wrapper div.live_data_content div.row div.c2 a'}],action: 'hit',event: 'click',values: ['social_media_panel','button_rss']},{selectors: [{type: 'normal',selector: 'div#live_data div.live_data_outer_wrapper div.live_data_inner_wrapper div.live_data_content div.row div.c3'},{type: 'normal',selector: 'div#live_data div.live_data_outer_wrapper div.live_data_inner_wrapper div.live_data_content div.row div.c2 h3'}],action: 'hit',event: 'click',values: ['social_media_panel','newscenter_link']},{selectors: [{type: 'normal',selector: 'div#live_data div.live_data_outer_wrapper div.live_data_inner_wrapper div.live_data_content div.row div.c2 div.row div.item_content a'}],action: 'hit',event: 'click',values: ['social_media_panel','newscenter_article']},{selectors: [{type: 'normal',selector: 'div#live_data div.live_data_outer_wrapper div.live_data_inner_wrapper div.live_data_content div.row div.c5 h3'}],action: 'hit',event: 'click',values: ['social_media_panel','twitter_link']},{selectors: [{type: 'normal',selector: 'div#live_data div.live_data_outer_wrapper div.live_data_inner_wrapper div.live_data_content div.row div.c6 div.mimic_link'}],action: 'hit',event: 'click',values: ['social_media_panel','twitter_tweet']},{selectors: [{type: 'normal',selector: 'div#live_data div.live_data_outer_wrapper div.live_data_inner_wrapper div.live_data_content div.row div.c4 div.row div.youtube h4'}],action: 'hit',event: 'click',values: ['social_media_panel','youtube_link']},{selectors: [{type: 'normal',selector: 'div#live_data div.live_data_outer_wrapper div.live_data_inner_wrapper div.live_data_content div.row div.c4 div.row div.flickr h4'}],action: 'hit',event: 'click',values: ['social_media_panel','flickr_link']},{selectors: [{type: 'normal',selector: 'div#sitemap_wrapper div.sitemap_link'}],action: 'hit',event: 'click',values: ['sitemap','button_open-close']},{selectors: [{type: 'normal',selector: 'div.topnav_wrapper div.topnav_content div.navigation_top_sub_items div.sub_items div.sub_item a'},{type: 'normal',selector: 'div.topnav_wrapper div.topnav_content div.row div.column a'}],action: 'cookie',event: 'nav_category',values: ['topmenu']},{selectors: [{type: 'normal',selector: 'div#p-header div#p-header-nav-site.p-clearfix ul.p-nav li.p-first'}],action: 'cookie',event: 'nav_category',values: ['topmenu_home-button']},{selectors: [{type: 'normal',selector: 'div#left_column div#left_menu_wrapper div#left_menu_content dl dd'}],action: 'cookie',event: 'nav_category',values: ['leftmenu']},{selectors: [{type: 'normal',selector: 'div#tailored_access_wrapper div#quick_access_content div.row div.c1 div.popular_content'}],action: 'cookie',event: 'nav_category',values: ['tailored_access_most-popular']},{selectors: [{type: 'normal',selector: 'div#tailored_access_wrapper div#quick_access_content div.row div.c1 div.popular_content a'},{type: 'normal',selector: 'div#tailored_access_wrapper_homepage div#quick_access_content div.row div.popular_content div#most_popular.popular_content_elements'}],action: 'cookie',event: 'nav_category',values: ['tailored_access_most-popular']},{selectors: [{type: 'normal',selector: 'div#tailored_access_wrapper div#quick_access_content div.row div.c1 div.button_wrapper_outer'},{type: 'normal',selector: 'div#tailored_access_wrapper div#quick_access_content div.row div.company'},{type: 'normal',selector: 'div#tailored_access_wrapper div#quick_access_content div.row div.financial'},{type: 'normal',selector: 'div#tailored_access_wrapper div#quick_access_content div.row div.sustainability'},{type: 'normal',selector: 'div#tailored_access_wrapper_homepage div#quick_access_content div.row div.company'},{type: 'normal',selector: 'div#tailored_access_wrapper_homepage div#quick_access_content div.row div.financial'},{type: 'normal',selector: 'div#tailored_access_wrapper_homepage div#quick_access_content div.row div.sustainability'}],action: 'cookie',event: 'nav_category',values: ['tailored_access']},{selectors: [{type: 'normal',selector: 'div#proofpoint_navigation_wrapper div#proofpoint_navigation_inner_wrapper div#proofpoint_navigation_position_top_wrapper div#proofpoint_navigation_content_wrapper div#proofpoint_navigation_content div.proofpoint_thumbnail'}],action: 'cookie',event: 'nav_category',values: ['proofpoint_navigation']},{selectors: [{type: 'normal',selector: 'div#main_column div#p-printarea table#related_content td.related_content_banners div.banner'},{type: 'normal',selector: 'div#main_column div#p-printarea table#related_content td.related_content_links ul.related_links li div.related_content_link'}],action: 'cookie',event: 'nav_category',values: ['related_content']},{selectors: [{type: 'normal',selector: 'div#main_column div#p-printarea div.strategy_outer_wrapper div.strategy_wrapper div.button_wrapper'}],action: 'cookie',event: 'nav_category',values: ['proofpoint_overview-button']},{selectors: [{type: 'normal',selector: 'div#main_column div#p-printarea div.strategy_outer_wrapper div.strategy_wrapper div.strategy_image'}],action: 'cookie',event: 'nav_category',values: ['proofpoint_overview-image']},{selectors: [{type: 'normal',selector: 'table#related_content tbody tr td.related_content_links ul.related_links li div.related_content_download'}],action: 'download',event: 'download',values: ['related_content']},{selectors: [{type: 'normal',selector: 'div#p-content div.p-main div#p-printarea div.download_page_header div.full_downloads_wrapper div.full_download'},{type: 'normal',selector: 'div.main_content_wrapper div.right_column div.right_content_items_wrapper div.right_content_item_wrapper div.right_content_item div.right_content_item_link'}],action: 'download',event: 'download',values: ['download_manager']},{selectors: [{type: 'normal',selector: 'div#p-body div#p-body-wrapper div#p-body-innerwrapper div#p-content div#main_column div#p-printarea div.excel_download_link'}],action: 'download',event: 'download',values: ['table_in_excel']}], dynamic: [{selectors: [{type: 'normal',selector: 'div#lb_components div.lb_container div.lb_template div.lb_wrapper table td.lb_tools_wrapper div.lb_tools div.download_graph'}],action: 'download',event: 'download',values: ['graph_from_lightbox']},{selectors: [{type: 'normal',selector: 'div#lb_components div.lb_container div.lb_template div.lb_wrapper div.lb_content td.title div.excel_download_link'}],action: 'download',event: 'download',values: ['table_in_excel-lightbox']},{selectors: [{type: 'normal',selector: 'div#lb_components div.lb_container div.lb_template div.lb_wrapper table div.lb_content div.pdf_step1 div.pdf_properties_in_cache div.pdf_download_report_button div.button_wrapper'}],action: 'hit',event: 'download',values: ['pdf_generator','download_cached_pdf']},{selectors: [{type: 'normal',selector: 'div#lb_components div.lb_container div.lb_template div.lb_wrapper table div.lb_content div.pdf_step2 div.pdf_download_report div.pdf_download_report_button div.button_wrapper'}],action: 'hit',event: 'download',values: ['pdf_generator','download_generated_pdf']},{selectors: [{type: 'normal',selector: 'div#lb_components div.lb_container div.lb_template div.lb_wrapper div.lb_footer td.prev'}],action: 'hit',event: 'click',values: ['lightbox','navigate_previous']},{selectors: [{type: 'normal',selector: 'div#lb_components div.lb_container div.lb_template div.lb_wrapper div.lb_footer td.next'}],action: 'hit',event: 'click',values: ['lightbox','navigate_next']},{selectors: [{type: 'normal',selector: 'div#sitemap_container.center_960 div#sitemap_content div#sitemap_inner_content td.column_wrapper div.sitemap_column_wrapper div:has(a)'}],action: 'cookie',event: 'nav_category',values: ['sitemap']}]};
var arrTranslations=[];
arrTranslations['annualreport']='Annual Report 2012';
arrTranslations['web_survey']='Web survey';
arrTranslations['send_to_a_friend_title']='Send to a friend';
arrTranslations['survey_title']='Help us improve this website';
arrTranslations['emea']='EMEA';
arrTranslations['asia']='Asia';
arrTranslations['north america']='North America';
arrTranslations['latin america']='Latin America';
arrTranslations['number_of_employees']='Number of employees';
arrTranslations['employees_female']='Employees female';
arrTranslations['employees_male']='Employees male';
arrTranslations['r_and_d_centers']='R & D centers';
arrTranslations['manufacturing_sites']='Manufacturing sites';
arrTranslations['dach']='DACH';
arrTranslations['benelux']='Benelux';
arrTranslations['united kingdom and ireland']='United Kingdom and Ireland';
arrTranslations['iberia']='Iberia';
arrTranslations['france']='France';
arrTranslations['nordics']='Nordics';
arrTranslations['italy, israel and greece']='Italy, Israel and Greece';
arrTranslations['russia and central asia']='Russia and Central Asia';
arrTranslations['central & east europe']='Central & East Europe';
arrTranslations['greater china']='Greater China';
arrTranslations['japan']='Japan';
arrTranslations['middle east and turkey']='Middle East and Turkey';
arrTranslations['indian subcontinent']='Indian Subcontinent';
arrTranslations['asean & pacific']='ASEAN & Pacific';
arrTranslations['north america']='North America';
arrTranslations['south america']='South America';
arrTranslations['africa']='Africa';
arrTranslations['population']='Population';
arrTranslations['lives_improved']='Lives improved';
arrTranslations['gdp']='GDP';
arrTranslations['million']='million';
arrTranslations['billion']='billions';
arrTranslations['lives_improved_header']='Lives Improved by Philips: 1.7 billion';
arrTranslations['lives_improved_footer']='To see how many lives Philips improved in a region in 2012, move your mouse over the world map.';
arrTranslations['our_company_header']='Our company';
arrTranslations['our_company_footer']='To find out about Philips\' regional presence, move your mouse over the world map.';

var objAllBomLinks = { links: [{id: "1", type: "management", value: "http://www.philips.com/sites/philipsglobal/about/company/management/management/fransvanhouten.page"}, {id: "2", type: "management", value: "http://www.philips.com/sites/philipsglobal/about/company/management/management/patrick_kung.page"}, {id: "3", type: "management", value: "http://www.philips.com/sites/philipsglobal/about/company/management/management/jim_andrew.page"}, {id: "4", type: "management", value: "http://www.philips.com/sites/philipsglobal/about/company/management/management/pieternota.page"}, {id: "5", type: "management", value: "http://www.philips.com/sites/philipsglobal/about/company/management/management/ericcoutinho.page"}, {id: "6", type: "management", value: "http://www.philips.com/sites/philipsglobal/about/company/management/management/ericrondolat.page"}, {id: "7", type: "management", value: "http://www.philips.com/sites/philipsglobal/about/company/management/management/deborahdisanzo.page"}, {id: "8", type: "management", value: "http://www.philips.com/sites/philipsglobal/about/company/management/management/carole_wainaina.page"}, {id: "9", type: "management", value: "http://www.philips.com/sites/philipsglobal/about/company/management/management/ronald_de_jong.page"}, {id: "10", type: "management", value: "http://www.philips.com/sites/philipsglobal/about/company/management/management/ronwirahadiraksa.page"}, {id: "11", type: "supervisory_board", value: "http://www.philips.com/about/company/management/supervisoryboard/index.page"}]};
var arrPages=[];
arrPages['forward_looking_statements']='2040271';
arrPages['mobile_website_content']='20397316';
arrPages['interactive_graphs_content']='20397317';
arrPages['the_stories']='33065856804';
arrPages['performance_highlights']='1153703';
arrPages['downloads']='56111655455';
arrPages['ceo_message']='1153794';
arrPages['notes_company']='1165533';
arrPages['auditor-report_company']='1166807';
arrPages['changes_in_equity']='1165169';
arrPages['notes_group']='1152247';
arrPages['auditor-report_group']='2044931';
arrPages['auditor-report_group_2']='12345';
arrPages['consolitdated-statements-income_group']='2041649';
arrPages['sustainability_statements']='2045459';
arrPages['auditor-report_sustainability']='2039318';
arrPages['gri_table']='2041511';
arrPages['interactive_chart']='interactive_charts';
arrPages['interactive_chart_content']='20397317';
arrPages['board_of_management']='2045464';
arrPages['supervisory_board']='2045466';
arrPages['contact']='2045467';
arrPages['our_company']='2045468';
arrPages['strategic_focus']='2045469';

var objSupportiveVideos={
	vids: [
{pageid: '20396206', videoid: 'f', selector: 'div#p-content div#main_column div.proofpoint_image_wrapper:eq(1)'},{pageid: '20396202', videoid: 'b', selector: 'div#p-content div#main_column div.proofpoint_image_wrapper:eq(1)'},{pageid: '20396219', videoid: 'd', selector: 'div#p-content div#main_column div.proofpoint_image_wrapper:eq(1)'}	]
};
